﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class App
    {
        static void Main(string[] args)
        {
            const int SHOW_MAX_CAPACITY = 100;

            int sellTickets = 75;
            int ticketsRemain = SHOW_MAX_CAPACITY - sellTickets;

            Console.WriteLine($"Ingressos vendidos: {sellTickets} de {SHOW_MAX_CAPACITY}");
            Console.WriteLine($"Ingressos restantes: {ticketsRemain}");

            Console.ReadLine();
        }
    }
}
