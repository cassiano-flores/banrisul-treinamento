﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class App
    {
        static void Main(string[] args)
        {
            //char emote = '😊'; // too many characters
            char emote = '☺';    // deu certo, porque é somente um caractere ASCII unicode

            Console.WriteLine($"{emote}");

            char letter = 'A';
            int letterInt = letter;

            Console.WriteLine($"{letterInt}"); // 65 = 'A' em ASCII

            string stringTrue = "TRUE";
            bool convertedString = Convert.ToBoolean(stringTrue);

            Console.WriteLine($"{stringTrue}");      // TRUE pois é string
            Console.WriteLine($"{convertedString}"); // True pois é booleano

            double earnedPoints = 84.68;
            int candies = (int)earnedPoints;

            Console.WriteLine($"{candies}"); // somente 84 pois é inteiro

            Console.ReadLine();
        }
    }
}
