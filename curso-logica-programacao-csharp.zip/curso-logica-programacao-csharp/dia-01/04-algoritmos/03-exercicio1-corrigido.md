# 1. Tarefa cotidiana

Ir trabalhar

```
[Acordar]
   ↓
[Levantar da cama]
   ↓
[Escovar os dentes]
   ↓
[Tomar banho]
   ↓
[Vestir-se com a roupa adequada de trabalho]
   ↓
[Tomar café da manhã]
   ↓
[Pegar mochila com itens necessários]
   ↓
[Checar se trancou portas e janelas]
   ↓
[Sair de casa]
   ↓
[Ir até o ponto de ônibus]
   ↓
[Ir até o ponto de ônibus]
   ↓
[Pegar o ônibus que leva até o trabalho]
```

## Lista numerada:

1. Acordar
2. Levantar da cama
3. Escovar os dentes
4. Tomar banho
5. Vestir-se com a roupa adequada de trabalho
6. Tomar café da manhã
7. Pegar mochila com itens necessários
8. Checar se trancou portas e janelas
9. Sair de casa
10. Ir até o ponto de ônibus
11. Ir até o ponto de ônibus
12. Pegar o ônibus que leva até o trabalho

## Pseudocódigo:

```pseudo
INÍCIO
   Acordar
   Levantar da cama
   Escovar os dentes
   Tomar banho
   Vestir-se com a roupa adequada de trabalho
   Tomar café da manhã
   Pegar mochila com itens necessários
   Checar se trancou portas e janelas
   Sair de casa
   Ir até o ponto de ônibus
   Ir até o ponto de ônibus
   Pegar o ônibus que leva até o trabalho
FIM
```