﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class App
    {
        public static void Main(string[] args)
        {
            Console.Write("Nome: ");
            string firstname = Console.ReadLine();

            Console.Write("Sobrenome: ");
            string lastname = Console.ReadLine();

            Console.WriteLine($"Fullname: {firstname} {lastname}");

            char firstNameLetter = firstname.ToUpper().ElementAt(0);
            char lastNameLetter = lastname.ToUpper().ElementAt(0);
            int lettersCount = $"{firstname}{lastname}".Trim().Length;
            Console.WriteLine($"Iniciais e contagem: {firstNameLetter}.{lastNameLetter}. ({lettersCount})");

            //////// primeira metade
            string hiddenName = "";
            bool firstNameEven = (firstname.Length % 2) != 0;
            for (int i = 0; i < firstname.Length / 2; i++)
            {
                hiddenName += firstname.ElementAt(i);
            }

            if (firstNameEven)
            {
                int halfFirst = firstname.Length / 2;
                hiddenName += firstname.ElementAt(halfFirst);
            }


            //////// segunda metade
            int halfLast = lastname.Length / 2;
            for (int i = halfLast; i < lastname.Length; i++)
            {
                hiddenName += lastname.ElementAt(i);
            }


            Console.WriteLine($"Nome secreto: {hiddenName}");

            Console.ReadLine();
        }
    }
}
