﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class App
    {
        public static void Main(string[] args)
        {
            Console.Write("Number 1: ");
            double number1 = double.Parse(Console.ReadLine());
            Console.Write("Number 2: ");
            double number2 = double.Parse(Console.ReadLine());

            // 1 para o 2
            Console.WriteLine($"\n=== {number1} -> {number2} ===");
            Console.WriteLine($"SOMA: {number1 + number2}");
            Console.WriteLine($"SUBTRAÇÃO: {number1 - number2}");
            Console.WriteLine($"MULTIPLICAÇÃO: {number1 * number2}");

            if (number2 == 0)
                Console.WriteLine($"DIVISÃO: NaN");
            else
                Console.WriteLine($"DIVISÃO: {number1 / number2}");

            Console.WriteLine($"RESTO: {number1 % number2}");

            // 2 para o 1
            Console.WriteLine($"\n=== {number2} -> {number1} ===");
            Console.WriteLine($"SOMA: {number2 + number1}");
            Console.WriteLine($"SUBTRAÇÃO: {number2 - number1}");
            Console.WriteLine($"MULTIPLICAÇÃO: {number2 * number1}");

            if (number1 == 0)
                Console.WriteLine($"DIVISÃO: NaN");
            else
                Console.WriteLine($"DIVISÃO: {number2 / number1}");

            Console.WriteLine($"RESTO: {number2 % number1}");

            Console.ReadLine();
        }
    }
}
