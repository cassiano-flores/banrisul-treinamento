﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class App
    {
        public static void Main(string[] args)
        {
            int number1;
            do
            {
                Console.Write("Digite um número inteiro de três dígitos: ");
                number1 = int.Parse(Console.ReadLine());

            } while ((number1 < 100) || (number1 > 999));
            
            int centena = number1 / 100;
            int dezena = (number1 - (100 * centena)) / 10;
            int unidade = number1 - (100 * centena) - (10 * dezena);
            int sumDigits = unidade + dezena + centena;

            Console.WriteLine($"\nUnidade: {unidade}" +
                              $"\nDezena: {dezena}" +
                              $"\nCentena: {centena}" +
                              $"\nSoma dos dígitos: {sumDigits}");

            Console.ReadLine();
        }
    }
}
