﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class ExtratoBancario
    {
        private string cpf;
        private string name;
        private decimal initialValue;
        private decimal finalValue;   // calculado com base no saldo inicial e aplicadas as movimentações
        List<Movimentacao> movimentations;

        public ExtratoBancario(string cpf, string name, decimal initialValue)
        {
            this.cpf = cpf;
            this.name = name;
            this.initialValue = initialValue;
            movimentations = new List<Movimentacao>();
        }

        public void AddMovimentation(Movimentacao movimentation)
        {
            movimentations.Add(movimentation);
            // ApurarSaldoFinal();
        }

        // responsável por calcular o valor do saldo final do extrato, com base no saldo inicial e a aplicação de todas as movimentações
        public void ApurarSaldoFinal()
        {
            finalValue = initialValue;
            foreach (Movimentacao movimentation in movimentations)
            {
                finalValue += movimentation.GetValue();
            }
        }

        // responsável por imprimir na tela o extrato bancário
        public string ImprimirRelatorio()
        {
            string movimentationsPrint = "";
            decimal auxValue = initialValue;

            foreach (Movimentacao movimentation in movimentations)
            {
                auxValue += movimentation.GetValue();
                movimentationsPrint += $"{movimentation.PrintReport()} --> Acumulado R$ {auxValue}" +
                                      $"\n";
            }

            string relatorio = $"Extrato bancário de: {name} (CPF: {cpf})" +
                            $"\n\n" +
                            $"Saldo inicial: R$ {initialValue}" +
                            $"\n\n" +
                            $"{movimentationsPrint}" +
                            $"\n" +
                            $"Saldo final: R$ {finalValue}";

            return relatorio;
        }
    }
}
