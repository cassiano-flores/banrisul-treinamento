﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Movimentacao
    {
        private DateTime time;
        private int value;
        private string description;

        public Movimentacao(DateTime time, int value, string description)
        {
            this.time = time;
            this.value = value;
            this.description = description;
        }

        public string PrintReport()
        {
            string signal;

            if (value < 0)
                signal = "-";
            else
                signal = "+";

            return $"Dia {time}: ({signal}) R$ {value} ({description})";
        }

        public int GetValue()
        {
            return value;
        }
    }
}
