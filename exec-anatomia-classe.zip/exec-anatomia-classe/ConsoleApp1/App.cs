﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class App
    {
        public static void Main(string[] args)
        {
            ExtratoBancario bankAccount = new ExtratoBancario("12345678900", "Cassiano", 1000);

            Movimentacao movimentation1 = new Movimentacao(new DateTime(2026, 01, 12, 10, 0, 0), -100, "Pix para mae");
            Movimentacao movimentation2 = new Movimentacao(new DateTime(2026, 01, 12, 12, 0, 0), -200, "Pix para irma");

            Movimentacao movimentation3 = new Movimentacao(new DateTime(2026, 01, 13, 13, 0, 0), 1000, "Salario");

            Movimentacao movimentation4 = new Movimentacao(new DateTime(2026, 01, 14, 14, 0, 0), 1000, "Vale");

            Movimentacao movimentation5 = new Movimentacao(new DateTime(2026, 01, 15, 15, 0, 0), -50, "Padaria");

            Movimentacao movimentation6 = new Movimentacao(new DateTime(2026, 01, 16, 16, 0, 0), -100, "Cafe");

            bankAccount.AddMovimentation(movimentation1);
            bankAccount.AddMovimentation(movimentation2);
            bankAccount.AddMovimentation(movimentation3);
            bankAccount.AddMovimentation(movimentation4);
            bankAccount.AddMovimentation(movimentation5);
            bankAccount.AddMovimentation(movimentation6);

            bankAccount.ApurarSaldoFinal();

            Console.WriteLine(bankAccount.ImprimirRelatorio());

            Console.ReadLine();
        }
    }
}
